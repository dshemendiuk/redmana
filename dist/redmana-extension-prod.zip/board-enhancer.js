(function($) {
    if (!$) {

        return;
    }

    $(document).ready(function() {
        const HEADER_ROW_SELECTOR = "table.list.issues-board:not(.sticky) > thead > tr";
        const headerRow = $(HEADER_ROW_SELECTOR);
        const bodyRow = $('table.list.issues-board:not(.sticky) > tbody > tr');

        if (!headerRow.length || !bodyRow.length) return;

        let suppressOrderObserver = false;
        let reapplyScheduled = false;

        function arraysEqual(arrA, arrB) {
            if (!Array.isArray(arrA) || !Array.isArray(arrB)) return false;
            if (arrA.length !== arrB.length) return false;
            for (let i = 0; i < arrA.length; i++) {
                if (arrA[i] !== arrB[i]) return false;
            }
            return true;
        }

        function getStickyHeaderRows() {
            return $('table.list.issues-board.sticky > thead > tr');
        }

        function reorderStickyColumns(orderIds) {
            if (!Array.isArray(orderIds) || !orderIds.length) return;
            const stickyRows = getStickyHeaderRows();
            if (!stickyRows.length) return;

            stickyRows.each(function() {
                const row = $(this);
                const currentOrder = row.find('th[data-column-id]').map(function() {
                    return $(this).data('column-id').toString();
                }).get();
                if (arraysEqual(currentOrder, orderIds)) {
                    return;
                }
                const stickyMap = new Map();
                row.find('th[data-column-id]').each(function() {
                    stickyMap.set($(this).data('column-id').toString(), this);
                });

                orderIds.forEach(id => {
                    const th = stickyMap.get(id.toString());
                    if (th) {
                        row.append(th);
                    }
                });
            });
        }

        function getSavedOrder() {
            const savedOrder = localStorage.getItem('redmanaColumnOrder');
            if (!savedOrder) return null;
            try {
                const orderedIds = JSON.parse(savedOrder);
                if (!Array.isArray(orderedIds) || !orderedIds.length) return null;
                return orderedIds.map(id => id.toString());
            } catch (e) {

                return null;
            }
        }

        function saveColumnOrder() {
            const orderedIds = headerRow.find('th[data-column-id]').map(function() {
                return $(this).data('column-id');
            }).get();
            localStorage.setItem('redmanaColumnOrder', JSON.stringify(orderedIds));

        }

        function applyColumnOrder(orderIds) {
            if (!Array.isArray(orderIds) || !orderIds.length) return false;

            const currentHeaderOrder = headerRow.find('th[data-column-id]').map(function() {
                return $(this).data('column-id').toString();
            }).get();
            const currentBodyOrder = bodyRow.find('td.issue-status-col[data-id]').map(function() {
                return $(this).data('id').toString();
            }).get();

            const headerChanged = !arraysEqual(currentHeaderOrder, orderIds);
            const bodyChanged = !arraysEqual(currentBodyOrder, orderIds);

            if (!headerChanged && !bodyChanged) {
                reorderStickyColumns(orderIds);
                return false;
            }

            const thMap = new Map();
            headerRow.find('th[data-column-id]').each(function() {
                thMap.set($(this).data('column-id').toString(), this);
            });

            const tdMap = new Map();
            bodyRow.find('td.issue-status-col[data-id]').each(function() {
                tdMap.set($(this).data('id').toString(), this);
            });

            let applied = false;
            if (headerChanged) {
                orderIds.forEach(id => {
                    const key = id.toString();
                    const th = thMap.get(key);
                    if (th) {
                        headerRow.append(th);
                        applied = true;
                    }
                });
            }
            if (bodyChanged) {
                orderIds.forEach(id => {
                    const key = id.toString();
                    const td = tdMap.get(key);
                    if (td) {
                        bodyRow.append(td);
                    }
                });
            }
            reorderStickyColumns(orderIds);
            return applied;
        }

        function applySavedColumnOrder(options = {}) {
            const { silent = false } = options;
            const orderedIds = getSavedOrder();
            if (!orderedIds) return;
            suppressOrderObserver = true;
            try {
                const applied = applyColumnOrder(orderedIds);
                if (applied && !silent) {

                }
            } catch (e) {

            } finally {
                suppressOrderObserver = false;
            }
        }

        applySavedColumnOrder();


        headerRow.on('mousedown', 'th', function() {
            headerRow.find('th').each(function() {
                $(this).data('original-width', $(this).width());
            });
        });

        headerRow.sortable({
            axis: 'x',
            placeholder: 'sortable-placeholder',
            tolerance: 'pointer',
            helper: 'clone',
            start: function(event, ui) {

                ui.placeholder.width(ui.helper.width());
                headerRow.find('th').each(function() {
                    $(this).width($(this).data('original-width'));
                });
            },
            stop: function(event, ui) {

                headerRow.find('th').each(function() {
                    $(this).css('width', '').removeData('original-width');
                });
            },
            update: function(event, ui) {

                const newOrderIds = $(this).find('th[data-column-id]').map(function() {
                    return $(this).data('column-id').toString();
                }).get();


                const bodyColumnsMap = new Map();
                bodyRow.find('td.issue-status-col[data-id]').each(function() {
                    bodyColumnsMap.set($(this).data('id').toString(), this);
                });


                newOrderIds.forEach(id => {
                    const td = bodyColumnsMap.get(id);
                    if (td) {
                        bodyRow.append(td);
                    }
                });

                reorderStickyColumns(newOrderIds);


                saveColumnOrder();
            }
        });

        function scheduleOrderReapply() {
            if (reapplyScheduled) return;
            reapplyScheduled = true;
            requestAnimationFrame(() => {
                reapplyScheduled = false;
                if (suppressOrderObserver) return;
                applySavedColumnOrder({ silent: true });
            });
        }

        const headerObserver = new MutationObserver(mutations => {
            if (suppressOrderObserver || isDraggingCard) return;
            const relevant = mutations.some(mutation => {
                if (mutation.type !== 'childList') return false;
                if (mutation.addedNodes.length === 0 && mutation.removedNodes.length === 0) return false;
                const target = mutation.target;
                if (!(target instanceof Element)) return false;
                if (target.closest && target.closest('td.issue-status-col')) {
                    return false;
                }
                return true;
            });
            if (!relevant) return;
            scheduleOrderReapply();
        });

        const mainThead = headerRow.closest('thead');
        if (mainThead.length) {
            headerObserver.observe(mainThead.get(0), { childList: true });
        }
        const stickyThead = $('table.list.issues-board.sticky > thead');
        if (stickyThead.length) {
            headerObserver.observe(stickyThead.get(0), { childList: true });
        }

        const boardTable = $('table.list.issues-board:not(.sticky)');
        if (boardTable.length) {
            headerObserver.observe(boardTable.get(0), { childList: true, subtree: true });
        }


        let isDraggingCard = false;
        let lastPointerY = null;
        let scrollAnimationFrame = null;

        function updatePointerY(positionY) {
            lastPointerY = positionY;
            if (isDraggingCard && scrollAnimationFrame === null) {
                scrollAnimationFrame = requestAnimationFrame(applyAutoScroll);
            }
        }

        function applyAutoScroll() {
            if (!isDraggingCard || lastPointerY === null) {
                scrollAnimationFrame = null;
                return;
            }

            const threshold = 80;
            const scrollStep = 30;
            const viewportHeight = window.innerHeight;
            const maxScrollTop = document.documentElement.scrollHeight - viewportHeight;
            let didScroll = false;

            if (lastPointerY < threshold && window.scrollY > 0) {
                window.scrollBy(0, -scrollStep);
                didScroll = true;
            } else if (lastPointerY > viewportHeight - threshold) {
                const nextScroll = Math.min(window.scrollY + scrollStep, maxScrollTop);
                if (nextScroll !== window.scrollY) {
                    window.scrollTo(0, nextScroll);
                    didScroll = true;
                }
            }

            if (didScroll) {
                scrollAnimationFrame = requestAnimationFrame(applyAutoScroll);
            } else {
                scrollAnimationFrame = null;
            }
        }

        function stopAutoScroll() {
            isDraggingCard = false;
            lastPointerY = null;
            if (scrollAnimationFrame !== null) {
                cancelAnimationFrame(scrollAnimationFrame);
                scrollAnimationFrame = null;
            }
        }

        $(document).on('sortstart.redmana', '.issue-status-col.ui-sortable', () => {
            isDraggingCard = true;
        });

        $(document).on('sortstop.redmana sortcancel.redmana', '.issue-status-col.ui-sortable', () => {
            stopAutoScroll();
        });

        document.addEventListener('mousemove', event => {
            if (!isDraggingCard) return;
            updatePointerY(event.clientY);
        });

        document.addEventListener('touchmove', event => {
            if (!isDraggingCard) return;
            if (event.touches && event.touches.length) {
                updatePointerY(event.touches[0].clientY);
            }
        }, { passive: true });

        ['mouseup', 'touchend', 'touchcancel', 'pointerup', 'pointercancel', 'dragend'].forEach(eventType => {
            document.addEventListener(eventType, () => {
                if (!isDraggingCard) return;
                stopAutoScroll();
            }, true);
        });
    });
})(window.jQuery);
