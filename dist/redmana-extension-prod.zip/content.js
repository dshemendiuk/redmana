

const HEADER_ROW_SELECTOR = "table.list.issues-board > thead > tr";
const ISSUE_PATH_REGEX = /^\/issues\/\d+$/;
const DRAWER_INIT_FLAG = "__redmanaDrawerInitialized";
const ASSIGNEE_INIT_FLAG = "__redmanaAssigneeInitialized";
const LATEST_ASSIGNEES_KEY = `redmanaLatestAssignees:${window.location.host}`;
const MAX_LATEST_ASSIGNEES = 10;
const LATEST_OPTGROUP_LABEL = 'Latest';
const ASSIGNEE_SELECT_SELECTOR = 'select[name="issue[assigned_to_id]"]';
const SELECTED_CLASS = 'redmana-issue-selected';
const BODY_DRAWER_CLASS = 'redmana-drawer-open';
const CURRENT_HOST_CANONICAL = normalizeHostname(window.location.hostname || '');
let lastKnownUrl = window.location.href;

function normalizeHostname(rawHost) {
    return (rawHost || '')
        .toString()
        .trim()
        .replace(/:\d+$/, '')
        .replace(/^www\./, '')
        .toLowerCase();
}

function clearStaleDrawerState() {
    try {
        const state = history.state;
        if (!state || state.redmanaDrawer !== true) {
            return;
        }
        const nextState = { ...state };
        delete nextState.redmanaDrawer;
        const sanitized = Object.keys(nextState).length ? nextState : null;
        history.replaceState(sanitized, '', window.location.href);
    } catch (error) {

    }
    lastKnownUrl = window.location.href;
}
function injectScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('board-enhancer.js');
    document.head.appendChild(script);
    script.remove();

}

function waitForBoardAndInject() {
    let attempts = 0;
    const maxAttempts = 50;
    const interval = setInterval(() => {
        const board = document.querySelector(HEADER_ROW_SELECTOR);
        if (board) {
            clearInterval(interval);
            injectScript();
        } else if (++attempts > maxAttempts) {
            clearInterval(interval);

        }
    }, 200);
}

function isLikelyRedmine() {
    const body = document.body;
    if (!body) return false;

    if (document.querySelector('meta[name="description"][content*="Redmine"]')) return true;
    if (document.querySelector('meta[name="application-name"][content*="Redmine"]')) return true;
    if (document.querySelector('meta[name="generator"][content*="Redmine"]')) return true;

    const bodyClasses = Array.from(body.classList || []);
    if (bodyClasses.some(cls => cls.startsWith('controller-')) &&
        bodyClasses.some(cls => cls.startsWith('action-'))) {
        return true;
    }

    if (document.querySelector('#top-menu') && document.querySelector('#header')) return true;
    if (document.querySelector('meta[name="csrf-token"]') && document.querySelector('meta[name="csrf-param"]')) {
        if (document.querySelector('#project-jump') || document.querySelector('#quick-search')) {
            return true;
        }
    }

    return false;
}

function navigateToIssuePage(issueUrl, reason) {
    try {

    } catch (error) {

    }
    forceCloseDrawer();
    const resolved = resolveIssueUrl(issueUrl);
    window.location.assign(resolved);
}
function forceCloseDrawer() {
    if (drawerState.isOpen) {
        closeDrawerInternal();
    }
}

const isRedmine = isLikelyRedmine();

if (isRedmine && document.body) {
    document.body.classList.add('redmana-loaded');
}

if (isRedmine) {
    clearStaleDrawerState();
}

if (isRedmine && window.location.pathname.includes('/agile/board')) {
    if (document.readyState === 'complete') {
        waitForBoardAndInject();
    } else {
        window.addEventListener('load', waitForBoardAndInject);
    }
}

const EXTERNAL_LIGHTBOX_SCRIPT_SELECTOR = [
    'script[src*="redmine_lightbox"]',
    'script[src*="fancybox"]',
    'script[src*="colorbox"]',
    'script[src*="magnific"]',
    'script[src*="photoswipe"]'
].join(', ');

const EXTERNAL_LIGHTBOX_OVERLAY_SELECTOR = [
    '.fancybox-container',
    '.fancybox-overlay',
    '.lb-outerContainer',
    '#colorbox',
    '.mfp-wrap',
    '.pswp--open'
].join(', ');

let externalLightboxPresent = false;

function detectExternalLightbox() {
    return !!document.querySelector(EXTERNAL_LIGHTBOX_SCRIPT_SELECTOR);
}

function externalLightboxHandledClick(event) {
    if (!externalLightboxPresent) {
        return false;
    }

    if (event.defaultPrevented) {
        return true;
    }

    return !!document.querySelector(EXTERNAL_LIGHTBOX_OVERLAY_SELECTOR);
}

function initLightbox() {
    externalLightboxPresent = detectExternalLightbox();

    document.body.addEventListener('click', function(event) {
        const thumbnailLink = event.target.closest('div.thumbnails a');

        if (!thumbnailLink) {
            return;
        }

        if (externalLightboxHandledClick(event)) {
            return;
        }

        const imgTag = thumbnailLink.querySelector('img');
        if (!imgTag) {

            return;
        }

        const attachmentHref = thumbnailLink.getAttribute('href');
        if (!attachmentHref) {

            return;
        }

        const titleName = imgTag.getAttribute('data-filename')
            || imgTag.getAttribute('title')
            || imgTag.getAttribute('alt')
            || '';
        const hrefFile = decodeURIComponent(attachmentHref).split('/').pop() || '';
        const candidateName = (titleName || hrefFile).trim();
        const imageExtensionPattern = /\.(png|jpe?g|gif|webp|bmp|svg)$/i;
        if (!candidateName || !imageExtensionPattern.test(candidateName)) {

            return;
        }

        const attachmentUrl = new URL(attachmentHref, window.location.origin);
        const idMatch = attachmentUrl.pathname.match(/\/attachments\/(?:download\/)?(\d+)/);
        const downloadFilename = candidateName.replace(/[/\\]/g, '_');
        const imageUrl = idMatch
            ? `${window.location.origin}/attachments/download/${idMatch[1]}/${encodeURIComponent(downloadFilename)}`
            : attachmentUrl.href;

        event.preventDefault();


        const overlay = document.createElement('div');
        overlay.className = 'redmana-lightbox-overlay';

        const content = document.createElement('div');
        content.className = 'redmana-lightbox-content';

        const img = document.createElement('img');
        img.src = imageUrl;

        content.appendChild(img);
        overlay.appendChild(content);


        overlay.addEventListener('click', () => {
            overlay.remove();
        });

        document.body.appendChild(overlay);
    });

}

if (isRedmine) {
    initLightbox();
}

const drawerState = {
    isOpen: false,
    baseUrl: null,
    currentUrl: null,
    activeRequestToken: null,
    renderedSignature: null,
    selectedElement: null
};

let drawerElements = null;
let assigneeObserver = null;

const DRAWER_BASE_Z_INDEX = 2147483000;

function bringDrawerToFront(container) {
    document.querySelectorAll('.redmana-drawer-container').forEach(element => {
        element.style.zIndex = String(element === container ? DRAWER_BASE_Z_INDEX + 1 : DRAWER_BASE_Z_INDEX);
    });
}

const drawerLayers = [];

const drawerLayerClosers = {};
let drawerHistoryPending = false;
let pendingDrawerClaim = null;

function topDrawerLayer() {
    return drawerLayers.length ? drawerLayers[drawerLayers.length - 1] : null;
}

function claimDrawerHistory(name, url, onReady) {
    const top = topDrawerLayer();
    try {
        if (top === name) {
            history.replaceState({ redmanaDrawer: true }, '', url);
        } else if (drawerLayers.includes(name)) {
            pendingDrawerClaim = () => claimDrawerHistory(name, url, onReady);
            if (!drawerHistoryPending) {
                drawerHistoryPending = true;
                history.back();
            }
            return;
        } else {
            history.pushState({ redmanaDrawer: true }, '', url);
            drawerLayers.push(name);
        }
    } catch (error) {

    }
    lastKnownUrl = window.location.href;
    onReady();
}

function replaceDrawerUrl(name, url) {
    if (topDrawerLayer() !== name) return;
    try {
        history.replaceState({ redmanaDrawer: true }, '', url);
        lastKnownUrl = window.location.href;
    } catch (error) {

    }
}

function requestDrawerLayerClose(name) {
    if (topDrawerLayer() === name) {
        if (!drawerHistoryPending) {
            drawerHistoryPending = true;
            history.back();
        }
        return;
    }


    const index = drawerLayers.lastIndexOf(name);
    if (index !== -1) {
        drawerLayers.splice(index, 1);
        drawerLayerClosers[name]();
    }
}

function forgetDrawerLayer(name) {
    const index = drawerLayers.lastIndexOf(name);
    if (index !== -1) drawerLayers.splice(index, 1);
}

function resolveIssueUrl(rawHref) {
    try {
        const url = new URL(rawHref, window.location.origin);
        const urlHost = normalizeHostname(url.hostname);

        if (window.location.protocol === 'https:' &&
            url.protocol === 'http:' &&
            urlHost === CURRENT_HOST_CANONICAL) {
            url.protocol = 'https:';
            url.port = '';
        }
        return url.toString();
    } catch (error) {

        return rawHref;
    }
}

function shouldHandleIssueLink(anchor) {
    const href = anchor.getAttribute('href');
    if (!href || href.startsWith('javascript:')) return false;
    if (anchor.target === '_blank' || anchor.hasAttribute('download')) return false;
    if (anchor.dataset.redmanaBypass === 'true') return false;
    if (anchor.closest('.tabs')) return false;

    let url;
    try {
        url = new URL(href, window.location.origin);
    } catch (error) {
        return false;
    }

    const normalizedPath = url.pathname.replace(/\/$/, '');
    if (!ISSUE_PATH_REGEX.test(normalizedPath)) {
        return false;
    }


    return url.origin === window.location.origin;
}

function ensureDrawerElements() {
    if (drawerElements) {
        return drawerElements;
    }

    const container = document.createElement('div');
    container.className = 'redmana-drawer-container';

    const drawer = document.createElement('aside');
    drawer.className = 'redmana-drawer';
    drawer.setAttribute('aria-hidden', 'true');

    const header = document.createElement('div');
    header.className = 'redmana-drawer-header';

    const title = document.createElement('h2');
    title.className = 'redmana-drawer-title';

    const titleLink = document.createElement('a');
    titleLink.className = 'redmana-drawer-title-link';
    titleLink.href = '#';
    titleLink.target = '_blank';
    titleLink.rel = 'noopener noreferrer';
    titleLink.textContent = 'Loading...';

    title.appendChild(titleLink);

    const actionGroup = document.createElement('div');
    actionGroup.className = 'redmana-drawer-actions';

    const closeButton = document.createElement('button');
    closeButton.className = 'redmana-drawer-close';
    closeButton.type = 'button';
    closeButton.setAttribute('aria-label', 'Close task drawer');
    closeButton.innerHTML = '&times;';

    actionGroup.appendChild(closeButton);

    const body = document.createElement('div');
    body.className = 'redmana-drawer-body';

    header.appendChild(title);
    header.appendChild(actionGroup);
    drawer.appendChild(header);
    drawer.appendChild(body);

    container.appendChild(drawer);

    document.body.appendChild(container);

    closeButton.addEventListener('click', () => requestDrawerLayerClose('issue'));

    drawerElements = {
        container,
        drawer,
        header,
        title,
        titleLink,
        actions: actionGroup,
        closeButton,
        body
    };

    return drawerElements;
}

function setDrawerTitle(text, url) {
    const elements = ensureDrawerElements();
    const label = (text && text.trim()) || 'Task';
    const href = url || drawerState.currentUrl || '#';

    elements.titleLink.textContent = label;
    elements.titleLink.href = href || '#';
    elements.titleLink.title = 'Open full issue page';
}

function showDrawerLoading(message = 'Loading...') {
    const elements = ensureDrawerElements();
    elements.body.innerHTML = '';
    const loading = document.createElement('div');
    loading.className = 'redmana-drawer-loading';
    loading.textContent = message;
    elements.body.appendChild(loading);
}

function showDrawerError(message) {
    const elements = ensureDrawerElements();
    elements.body.innerHTML = '';
    const alert = document.createElement('div');
    alert.className = 'redmana-drawer-alert';
    alert.textContent = message || 'Unable to load the task. Please try again.';
    elements.body.appendChild(alert);
}

function closeDrawerInternal() {
    if (!drawerState.isOpen) return;
    forgetDrawerLayer('issue');
    restoreShadowedPageIds();
    const elements = ensureDrawerElements();
    elements.container.classList.remove('is-open');
    elements.drawer.setAttribute('aria-hidden', 'true');
    if (document.body) {
        document.body.classList.remove(BODY_DRAWER_CLASS);
    }
    drawerState.isOpen = false;
    drawerState.baseUrl = null;
    drawerState.currentUrl = null;
    drawerState.renderedSignature = null;
    lastKnownUrl = window.location.href;

    clearHighlightedIssue();



    drawerState.activeRequestToken = null;

    setTimeout(() => {
        elements.body.scrollTop = 0;
        setDrawerTitle('Loading...', '#');
        showDrawerLoading();
    }, 200);
}

const ISSUE_HTML_CACHE_TTL_MS = 300000;

const REVALIDATE_AFTER_MS = 5000;
const PREFETCH_HOVER_DELAY_MS = 150;
const MAX_CACHED_ISSUES = 12;

const MAX_INFLIGHT_PREFETCHES = 2;

const issueHtmlCache = new Map();

let issuePagesInFlight = 0;
let issuePagesIdleWaiters = [];

function whenIssuePagesIdle() {
    if (!issuePagesInFlight) return Promise.resolve();
    return new Promise(resolve => issuePagesIdleWaiters.push(resolve));
}

function trackIssuePageRequest(promise) {
    issuePagesInFlight += 1;
    const settle = () => {
        issuePagesInFlight -= 1;
        if (!issuePagesInFlight) {
            const waiters = issuePagesIdleWaiters;
            issuePagesIdleWaiters = [];
            waiters.forEach(resolve => resolve());
        }
    };
    promise.then(settle, settle);
    return promise;
}
let prefetchHoverTimer = null;
let prefetchHoverUrl = null;
let inflightPrefetches = 0;

function issueRequestUrl(issueUrl) {
    const url = new URL(issueUrl, window.location.origin);
    return `${url.origin}${url.pathname}${url.search}`;
}

function pruneIssueHtmlCache() {
    const now = Date.now();
    issueHtmlCache.forEach((entry, key) => {
        if (entry.html !== undefined && now - entry.fetchedAt > ISSUE_HTML_CACHE_TTL_MS) {
            issueHtmlCache.delete(key);
        }
    });


    while (issueHtmlCache.size > MAX_CACHED_ISSUES) {
        const oldestKey = issueHtmlCache.keys().next().value;
        issueHtmlCache.delete(oldestKey);
    }
}

function fetchIssueHtml(requestUrl, { force = false } = {}) {
    pruneIssueHtmlCache();

    if (force) {
        issueHtmlCache.delete(requestUrl);
    } else {
        const cached = issueHtmlCache.get(requestUrl);
        if (cached) {
            return cached.promise;
        }
    }

    const entry = { fetchedAt: Date.now(), html: undefined, finalUrl: requestUrl };
    entry.promise = trackIssuePageRequest(fetch(requestUrl, { credentials: 'include' }))
        .then(response => {
            if (!response.ok) {
                throw new Error(`Response not OK (${response.status})`);
            }
            entry.finalUrl = response.url || requestUrl;
            return response.text();
        })
        .then(html => {
            entry.html = html;
            entry.fetchedAt = Date.now();
            return { html, finalUrl: entry.finalUrl };
        })
        .catch(error => {

            issueHtmlCache.delete(requestUrl);
            throw error;
        });

    issueHtmlCache.set(requestUrl, entry);
    return entry.promise;
}

function invalidateIssueHtml(issueUrl) {
    try {
        issueHtmlCache.delete(issueRequestUrl(issueUrl));
    } catch (error) {

    }
}

function prefetchIssue(issueUrl) {
    let requestUrl;
    try {
        requestUrl = issueRequestUrl(issueUrl);
    } catch (error) {
        return;
    }

    if (issueHtmlCache.has(requestUrl) || inflightPrefetches >= MAX_INFLIGHT_PREFETCHES) {
        return;
    }

    inflightPrefetches += 1;
    fetchIssueHtml(requestUrl)
        .catch(() => {

        })
        .finally(() => {
            inflightPrefetches -= 1;
        });
}

function cancelPrefetchHover() {
    if (prefetchHoverTimer !== null) {
        clearTimeout(prefetchHoverTimer);
        prefetchHoverTimer = null;
    }
    prefetchHoverUrl = null;
}

function handleIssuePrefetchHover(event) {
    const anchor = event.target.closest && event.target.closest('a[href]');
    if (!anchor || !shouldHandleIssueLink(anchor)) {
        cancelPrefetchHover();
        return;
    }

    const issueUrl = resolveIssueUrl(anchor.getAttribute('href'));
    if (issueUrl === prefetchHoverUrl) {
        return;
    }

    cancelPrefetchHover();
    prefetchHoverUrl = issueUrl;
    prefetchHoverTimer = setTimeout(() => {
        prefetchHoverTimer = null;
        prefetchIssue(issueUrl);
    }, PREFETCH_HOVER_DELAY_MS);
}

function handleIssuePrefetchIntent(event) {
    if (event.button !== undefined && event.button !== 0) return;


    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
    const anchor = event.target.closest && event.target.closest('a[href]');
    if (!anchor || !shouldHandleIssueLink(anchor)) return;

    cancelPrefetchHover();
    prefetchIssue(resolveIssueUrl(anchor.getAttribute('href')));
}

const ISSUE_LABELS_KEY = `redmanaIssueLabels:${window.location.host}`;

const DEFAULT_ISSUE_LABELS = {
    status: 'Status:',
    priority: 'Priority:',
    'assigned-to': 'Assignee:',
    'start-date': 'Start date:',
    'due-date': 'Due date:',
    progress: '% Done:',
    description: 'Description'
};
const MAX_KNOWN_ISSUES = 500;
const MAX_PREVIEW_DESCRIPTION_LENGTH = 3000;

const knownIssueData = new Map();

function rememberIssueData(issue) {
    if (!issue || !issue.id) return;
    knownIssueData.delete(issue.id);
    knownIssueData.set(issue.id, issue);
    while (knownIssueData.size > MAX_KNOWN_ISSUES) {
        knownIssueData.delete(knownIssueData.keys().next().value);
    }
}

function loadIssueLabels() {
    try {
        return { ...DEFAULT_ISSUE_LABELS, ...JSON.parse(localStorage.getItem(ISSUE_LABELS_KEY) || '{}') };
    } catch (error) {
        return { ...DEFAULT_ISSUE_LABELS };
    }
}

function learnIssueLabels(content) {
    const learned = {};
    content.querySelectorAll('.issue .attributes .attribute').forEach(attribute => {
        const key = Object.keys(DEFAULT_ISSUE_LABELS).find(name => attribute.classList.contains(name));
        const label = attribute.querySelector('.label');
        if (key && label) learned[key] = label.textContent.trim();
    });
    const description = content.querySelector('.issue .description p strong');
    if (description) learned.description = description.textContent.trim();
    if (!Object.keys(learned).length) return;

    try {
        const serialized = JSON.stringify(learned);
        if (localStorage.getItem(ISSUE_LABELS_KEY) !== serialized) {
            localStorage.setItem(ISSUE_LABELS_KEY, serialized);
        }
    } catch (error) {

    }
}

function classNumber(element, prefix) {
    const match = (element.className || '').match(new RegExp(`(?:^|\\s)${prefix}-(\\d+)(?:\\s|$)`));
    return match ? Number(match[1]) : null;
}

function cellText(row, className) {
    const cell = row.querySelector(`td.${className}`);
    const text = cell ? cell.textContent.trim() : '';
    return text || null;
}

function avatarFrom(container) {
    const img = container && container.querySelector('img.gravatar, img.avatar');
    return img ? { src: img.currentSrc || img.src, srcset: img.getAttribute('srcset') } : null;
}

function readIssueContext(data, anchor) {
    const card = anchor.closest('.issue-card');
    if (card) {
        const reference = card.querySelector('.issue-id strong');
        if (reference && !data.tracker) {
            data.tracker = reference.textContent.replace(/#\d+.*$/, '').trim() || null;
        }
        const name = card.querySelector('p.name a');
        if (name && !data.subject) data.subject = name.textContent.trim();

        const column = card.closest('td[data-id]');
        if (column && !data.status) {
            const heading = document.querySelector(`table.issues-board thead th[data-column-id="${column.dataset.id}"]`);
            if (heading) {
                data.statusId = Number(column.dataset.id);
                data.status = heading.textContent.replace(/\s*\(\d+\)\s*$/, '').trim();
            }
        }

        const assignee = card.querySelector('.assigned-user a.user');
        if (assignee && !data.assignee) {
            data.assignee = { name: assignee.textContent.trim(), href: assignee.getAttribute('href'), avatar: avatarFrom(assignee.parentElement) };
        }
        return;
    }

    const row = anchor.closest('tr.issue');
    if (!row) return;
    data.trackerId = data.trackerId || classNumber(row, 'tracker');
    data.statusId = data.statusId || classNumber(row, 'status');
    data.priorityId = data.priorityId || classNumber(row, 'priority');
    data.tracker = data.tracker || cellText(row, 'tracker');
    data.status = data.status || cellText(row, 'status');
    data.priority = data.priority || cellText(row, 'priority');
    data.subject = data.subject || cellText(row, 'subject');
    data.startDate = data.startDate || cellText(row, 'start_date');
    data.dueDate = data.dueDate || cellText(row, 'due_date');
    if (data.doneRatio === undefined || data.doneRatio === null) {
        const done = cellText(row, 'done_ratio');
        if (done) data.doneRatio = parseInt(done, 10) || 0;
    }
    const assignee = row.querySelector('td.assigned_to a');
    if (assignee && !data.assignee) {
        data.assignee = { name: assignee.textContent.trim(), href: assignee.getAttribute('href'), avatar: avatarFrom(assignee.parentElement) };
    }
}

function issuePreviewData(issueId, triggerElement) {
    const data = { id: issueId };

    const known = knownIssueData.get(Number(issueId));
    if (known) {
        Object.assign(data, {
            trackerId: known.tracker ? known.tracker.id : null,
            tracker: known.tracker ? known.tracker.name : null,
            subject: known.subject,
            statusId: known.status ? known.status.id : null,
            status: known.status ? known.status.name : null,
            priorityId: known.priority ? known.priority.id : null,
            priority: known.priority ? known.priority.name : null,
            assignee: known.assigned_to ? { name: known.assigned_to.name, href: `/users/${known.assigned_to.id}` } : null,
            startDate: known.start_date || null,
            dueDate: known.due_date || null,
            doneRatio: known.done_ratio,
            description: known.description
        });
    }

    if (triggerElement) {
        readIssueContext(data, triggerElement);

        if (!data.subject && triggerElement.title) data.subject = triggerElement.title.trim();
        if (!data.tracker) {
            const match = triggerElement.textContent.trim().match(/^(.+?)\s+#\d+/);
            if (match) data.tracker = match[1];
        }
    }

    return data.subject || data.tracker ? data : null;
}

function previewElement(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined && text !== null) element.textContent = text;
    return element;
}

function previewAttribute(key, label, valueContent) {
    const attribute = previewElement('div', `${key} attribute`);
    const value = previewElement('div', 'value');
    if (typeof valueContent === 'string') value.textContent = valueContent;
    else value.appendChild(valueContent);
    attribute.append(previewElement('div', 'label', label), value);
    return attribute;
}

function previewSkeleton(rows) {
    const skeleton = previewElement('div', 'redmana-uo-skeleton');
    for (let i = 0; i < rows; i += 1) {
        const row = previewElement('div', 'redmana-uo-skeleton-row');
        row.append(previewElement('span', 'redmana-uo-skeleton-bar'), previewElement('span', 'redmana-uo-skeleton-bar is-short'));
        skeleton.appendChild(row);
    }
    return skeleton;
}

function renderIssuePreview(data) {
    const labels = loadIssueLabels();
    const root = previewElement('div', 'redmana-issue-preview');
    root.id = 'redmana-drawer-content';
    root.setAttribute('aria-busy', 'true');

    const heading = data.tracker ? `${data.tracker} #${data.id}` : `#${data.id}`;
    root.appendChild(previewElement('h2', 'inline-block', heading));

    const issueClasses = ['issue', 'details'];
    if (data.trackerId) issueClasses.push(`tracker-${data.trackerId}`);
    if (data.statusId) issueClasses.push(`status-${data.statusId}`);
    if (data.priorityId) issueClasses.push(`priority-${data.priorityId}`);
    const issue = previewElement('div', issueClasses.join(' '));

    const subject = previewElement('div', 'subject');
    const subjectInner = previewElement('div');
    subjectInner.appendChild(previewElement('h3', null, data.subject || ''));
    subject.appendChild(subjectInner);
    issue.appendChild(subject);

    const left = previewElement('div', 'splitcontentleft');
    const right = previewElement('div', 'splitcontentleft');
    if (data.status) left.appendChild(previewAttribute('status', labels.status, data.status));
    if (data.priority) left.appendChild(previewAttribute('priority', labels.priority, data.priority));
    if (data.assignee) {
        const value = document.createDocumentFragment();
        if (data.assignee.avatar) {
            const img = previewElement('img', 'gravatar avatar');
            img.src = data.assignee.avatar.src;
            if (data.assignee.avatar.srcset) img.setAttribute('srcset', data.assignee.avatar.srcset);
            img.alt = '';
            value.append(img, ' ');
        }
        const link = previewElement('a', 'user active', data.assignee.name);
        link.href = data.assignee.href;
        value.appendChild(link);
        left.appendChild(previewAttribute('assigned-to', labels['assigned-to'], value));
    }
    if (data.startDate) right.appendChild(previewAttribute('start-date', labels['start-date'], data.startDate));
    if (data.dueDate) right.appendChild(previewAttribute('due-date', labels['due-date'], data.dueDate));
    if (data.doneRatio !== undefined && data.doneRatio !== null) {
        right.appendChild(previewAttribute('progress', labels.progress, `${data.doneRatio}%`));
    }
    if (left.childElementCount || right.childElementCount) {
        const attributes = previewElement('div', 'attributes');
        const split = previewElement('div', 'splitcontent');
        split.append(left, right);
        attributes.appendChild(split);
        issue.appendChild(attributes);
    }

    issue.appendChild(previewElement('hr'));
    const description = previewElement('div', 'description');
    const descriptionTitle = previewElement('p');
    descriptionTitle.appendChild(previewElement('strong', null, labels.description));
    description.appendChild(descriptionTitle);
    if (data.description) {

        const text = data.description.length > MAX_PREVIEW_DESCRIPTION_LENGTH
            ? `${data.description.slice(0, MAX_PREVIEW_DESCRIPTION_LENGTH)}…`
            : data.description;
        description.appendChild(previewElement('div', 'wiki redmana-issue-preview-text', text));
    } else {
        description.appendChild(previewSkeleton(3));
    }
    issue.appendChild(description);
    root.appendChild(issue);


    root.appendChild(previewSkeleton(4));
    return root;
}

function showIssuePreview(issueUrl, triggerElement) {
    const issueId = extractIssueIdFromUrl(issueUrl);
    const data = issueId ? issuePreviewData(issueId, triggerElement) : null;
    if (!data) return false;

    const elements = ensureDrawerElements();
    setDrawerTitle(data.tracker ? `${data.tracker} #${data.id}` : `#${data.id}`, issueUrl);
    restoreShadowedPageIds();
    elements.body.innerHTML = '';
    elements.body.scrollTop = 0;
    elements.body.appendChild(renderIssuePreview(data));
    return true;
}

async function loadIssueIntoDrawer(issueUrl, { force = false, triggerElement = null } = {}) {
    ensureDrawerElements();
    const urlObj = new URL(issueUrl, window.location.origin);
    const requestUrl = `${urlObj.origin}${urlObj.pathname}${urlObj.search}`;
    const anchor = urlObj.hash;

    const requestToken = Symbol('drawerRequest');
    drawerState.activeRequestToken = requestToken;

    const cached = !force && issueHtmlCache.get(requestUrl);
    const isWarm = !!(cached && cached.html !== undefined);
    const shouldRevalidate = isWarm && (Date.now() - cached.fetchedAt) > REVALIDATE_AFTER_MS;


    if (!isWarm && !showIssuePreview(issueUrl, triggerElement)) {
        setDrawerTitle('Loading...', issueUrl);
        showDrawerLoading();
    }

    let effectiveIssueUrl = issueUrl;

    try {
        const { html, finalUrl } = await fetchIssueHtml(requestUrl, { force });


        if (drawerState.activeRequestToken !== requestToken) {
            return;
        }

        if (!html || !html.trim()) {
            navigateToIssuePage(issueUrl, 'Empty issue response.');
            return;
        }

        const finalUrlBase = resolveIssueUrl(finalUrl || requestUrl);
        effectiveIssueUrl = anchor ? `${finalUrlBase}${anchor}` : finalUrlBase;
        drawerState.currentUrl = effectiveIssueUrl;

        if (drawerState.isOpen) {
            replaceDrawerUrl('issue', effectiveIssueUrl);
        }

        const content = parseIssueContent(html);

        if (!content) {
            navigateToIssuePage(issueUrl, 'Issue content container missing.');
            return;
        }

        renderIssueContent(content, effectiveIssueUrl, anchor);

        if (shouldRevalidate) {



            revalidateDrawerIssue(requestUrl, requestToken, effectiveIssueUrl, anchor);
        }
    } catch (error) {
        if (drawerState.activeRequestToken !== requestToken) {
            return;
        }

        navigateToIssuePage(issueUrl, error && error.message ? error.message : error);
        return;
    } finally {
        if (drawerState.activeRequestToken === requestToken) {
            drawerState.activeRequestToken = null;
        }
    }
}

function parseIssueContent(html) {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.querySelector('#content');
}

function renderIssueContent(content, effectiveIssueUrl, anchor, { preserveScroll = false } = {}) {
    const elements = ensureDrawerElements();
    const previousScroll = preserveScroll ? elements.body.scrollTop : 0;

    const clonedContent = content.cloneNode(true);
    clonedContent.id = 'redmana-drawer-content';
    clonedContent.querySelectorAll('script, link[rel="stylesheet"]').forEach(el => el.remove());

    const heading = clonedContent.querySelector('h2');
    const titleText = heading ? heading.textContent.trim() : 'Task';
    setDrawerTitle(titleText, effectiveIssueUrl);

    elements.body.innerHTML = '';
    elements.body.appendChild(clonedContent);
    elements.body.scrollTop = previousScroll;
    shadowDuplicatePageIds(clonedContent);

    drawerState.renderedSignature = issueContentSignature(content);
    learnIssueLabels(content);

    attachDrawerEnhancements(clonedContent, effectiveIssueUrl);
    highlightIssueContext(effectiveIssueUrl);

    if (anchor && !preserveScroll) {
        const target = clonedContent.querySelector(anchor);
        if (target) {
            scrollDrawerToElement(target);
        }
    }
}

function issueContentSignature(content) {
    const copy = content.cloneNode(true);
    copy.querySelectorAll('input[name="authenticity_token"]').forEach(el => el.setAttribute('value', ''));
    copy.querySelectorAll('form[name]').forEach(el => el.removeAttribute('name'));
    copy.querySelectorAll('[id^="form-"]').forEach(el => el.removeAttribute('id'));
    return copy.innerHTML;
}

function drawerHasUnsavedInput() {
    const elements = ensureDrawerElements();
    const root = elements.body;

    if (root.contains(document.activeElement) && document.activeElement !== root) {
        const active = document.activeElement;
        if (active.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName)) {
            return true;
        }
    }

    const fields = root.querySelectorAll('input, textarea, select');
    for (const field of fields) {
        if (field.type === 'hidden' || field.disabled) continue;

        if (field.tagName === 'SELECT') {



            const selected = Array.from(field.selectedOptions).map(option => option.value).sort();
            const original = Array.from(field.options).filter(option => option.defaultSelected).map(option => option.value).sort();

            if (!original.length && !field.multiple) {

                const fallback = field.options[0] ? field.options[0].value : '';
                if (field.value !== fallback) return true;
                continue;
            }

            if (selected.join('\u0000') !== original.join('\u0000')) return true;
            continue;
        }

        if (field.type === 'checkbox' || field.type === 'radio') {
            if (field.checked !== field.defaultChecked) return true;
            continue;
        }

        if (field.type === 'file') {
            if (field.files && field.files.length) return true;
            continue;
        }

        if (field.value !== field.defaultValue) return true;
    }

    return !!root.querySelector('[contenteditable="true"]:not(:empty)');
}

async function revalidateDrawerIssue(requestUrl, requestToken, effectiveIssueUrl, anchor) {
    let fresh;
    try {
        fresh = await fetchIssueHtml(requestUrl, { force: true });
    } catch (error) {
        console.warn('Redmana: Background refresh failed; keeping the cached view.', error);
        return;
    }


    if (drawerState.activeRequestToken !== null && drawerState.activeRequestToken !== requestToken) {
        return;
    }
    if (!drawerState.isOpen || drawerState.currentUrl !== effectiveIssueUrl) {
        return;
    }

    const content = parseIssueContent(fresh.html);
    if (!content) return;

    if (issueContentSignature(content) === drawerState.renderedSignature) {
        return;
    }

    if (drawerHasUnsavedInput()) {

        return;
    }

    renderIssueContent(content, effectiveIssueUrl, anchor, { preserveScroll: true });
}

const SHADOWED_ID_SCOPE_SELECTOR = '#update, #update [id], form[id], form [id]';
let shadowedPageElements = [];

function shadowDuplicatePageIds(drawerContent) {
    restoreShadowedPageIds();
    drawerContent.querySelectorAll(SHADOWED_ID_SCOPE_SELECTOR).forEach(element => {
        const pageElement = document.getElementById(element.id);
        if (!pageElement || pageElement === element || pageElement.closest('.redmana-drawer-container')) return;


        const pinnedHidden = !pageElement.style.display && getComputedStyle(pageElement).display === 'none';
        if (pinnedHidden) pageElement.style.display = 'none';

        shadowedPageElements.push({ element: pageElement, id: pageElement.id, pinnedHidden });
        pageElement.removeAttribute('id');
    });
}

function restoreShadowedPageIds() {


    shadowedPageElements.forEach(({ element, id, pinnedHidden }) => {
        element.id = id;
        if (pinnedHidden && element.style.display === 'none') element.style.removeProperty('display');
    });
    shadowedPageElements = [];
}

function attachDrawerEnhancements(drawerContent, issueUrl) {
    enhanceIssueForms(drawerContent, issueUrl);
    normalizeLinks(drawerContent);
    revealIssueHistory(drawerContent);
    enableDrawerAnchorNavigation(drawerContent, issueUrl);
}

function normalizeLinks(drawerContent) {
    drawerContent.querySelectorAll('a[href]').forEach(link => {
        const href = link.getAttribute('href');
        if (!href || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return;

        link.href = resolveIssueUrl(href);
    });
}

function revealIssueHistory(drawerContent) {
    drawerContent.querySelectorAll('.tab-content').forEach(section => {
        section.classList.remove('hidden');
        section.style.removeProperty('display');
        if (window.getComputedStyle(section).display === 'none') {
            section.style.display = 'block';
        }
    });

    drawerContent.querySelectorAll('#history, .history, .journal, #issue-changesets, #issue-changesets + .tab-content')
        .forEach(element => {
            element.classList.remove('hidden');
            element.style.removeProperty('display');
        });

    drawerContent.querySelectorAll('.tabs').forEach(tabs => {
        tabs.classList.add('redmana-drawer-tabs');
        tabs.classList.remove('hidden');
        tabs.style.removeProperty('display');
    });
}

function scrollDrawerToElement(targetElement, options = {}) {
    if (!targetElement) return;
    const { smooth = false } = options;
    const drawerBody = targetElement.closest('.redmana-drawer-body');
    const behavior = smooth ? 'smooth' : 'auto';

    if (drawerBody) {
        const drawerRect = drawerBody.getBoundingClientRect();
        const targetRect = targetElement.getBoundingClientRect();
        const nextScrollTop = drawerBody.scrollTop + (targetRect.top - drawerRect.top);
        drawerBody.scrollTo({ top: nextScrollTop, behavior });
    } else {
        targetElement.scrollIntoView({ block: 'start', behavior });
    }
}

function enableDrawerAnchorNavigation(drawerContent, issueUrl) {
    if (!drawerContent) return;

    let baseUrl;
    try {
        baseUrl = new URL(issueUrl, window.location.origin);
    } catch (error) {

        return;
    }

    const normalizePathname = pathname => (pathname || '').replace(/\/+$/, '');

    drawerContent.addEventListener('click', event => {
        if (event.defaultPrevented || event.button !== 0) return;
        const anchor = event.target.closest('a[href]');
        if (!anchor) return;

        const rawHref = anchor.getAttribute('href');
        if (!rawHref) return;

        let targetHash = null;

        if (rawHref.startsWith('#')) {
            targetHash = rawHref;
        } else {
            let resolvedUrl;
            try {
                resolvedUrl = new URL(resolveIssueUrl(rawHref));
            } catch (error) {
                return;
            }

            if (normalizePathname(resolvedUrl.pathname) !== normalizePathname(baseUrl.pathname)) {
                return;
            }

            targetHash = resolvedUrl.hash || '';
        }

        if (!targetHash || targetHash === '#') return;

        const selector = targetHash.startsWith('#') ? targetHash : `#${targetHash}`;
        const targetElement = drawerContent.querySelector(selector);
        if (!targetElement) return;

        event.preventDefault();
        event.stopPropagation();

        const updatedUrl = `${baseUrl.origin}${baseUrl.pathname}${baseUrl.search}${selector}`;
        replaceDrawerUrl('issue', updatedUrl);
        drawerState.currentUrl = updatedUrl;

        scrollDrawerToElement(targetElement, { smooth: true });
    });
}

function enhanceIssueForms(drawerContent, issueUrl) {
    const issueForm = drawerContent.querySelector('form#issue-form');
    if (!issueForm) {
        return;
    }

    const statusMessage = document.createElement('div');
    statusMessage.className = 'redmana-drawer-alert redmana-drawer-alert--hidden';
    issueForm.prepend(statusMessage);

    issueForm.addEventListener('submit', async event => {
        event.preventDefault();
        statusMessage.classList.add('redmana-drawer-alert--hidden');
        await submitIssueForm(issueForm, issueUrl, statusMessage);
    });
}

async function submitIssueForm(form, issueUrl, statusMessage) {
    const submitButtons = Array.from(form.querySelectorAll('input[type="submit"], button[type="submit"]'));
    submitButtons.forEach(button => {
        button.dataset.originalText = button.innerText || button.value || '';
        if (button.tagName === 'INPUT') {
            button.value = 'Saving...';
        } else {
            button.innerText = 'Saving...';
        }
        button.disabled = true;
    });

    const formData = new FormData(form);
    const method = (form.getAttribute('method') || 'post').toUpperCase();
    const action = resolveIssueUrl(form.getAttribute('action') || issueUrl);

    try {
        const response = await fetch(action, {
            method,
            credentials: 'include',
            body: formData,
            redirect: 'manual'
        });

        const isOpaqueRedirect = response.type === 'opaqueredirect';
        const isRedirectStatus = response.status >= 300 && response.status < 400;

        if (!response.ok && !isRedirectStatus && !isOpaqueRedirect) {
            throw new Error(`Failed to submit form (${response.status})`);
        }

        const redirectLocation = response.headers ? response.headers.get('Location') : null;
        const nextUrl = redirectLocation ? resolveIssueUrl(redirectLocation) : issueUrl;

        invalidateIssueHtml(nextUrl);
        await loadIssueIntoDrawer(nextUrl, { force: true });
        showTemporaryMessage('Task updated.', 'success');
    } catch (error) {

        if (statusMessage) {
            statusMessage.textContent = 'Unable to save changes. Review the form and try again.';
            statusMessage.classList.remove('redmana-drawer-alert--hidden');
        }
    } finally {
        submitButtons.forEach(button => {
            const originalText = button.dataset.originalText || '';
            if (button.tagName === 'INPUT') {
                button.value = originalText;
            } else {
                button.innerText = originalText;
            }
            button.disabled = false;
        });
    }
}

function showTemporaryMessage(message, type = 'info') {
    const elements = ensureDrawerElements();
    const banner = document.createElement('div');
    banner.className = `redmana-drawer-toast redmana-drawer-toast--${type}`;
    banner.textContent = message;
    elements.container.appendChild(banner);

    requestAnimationFrame(() => {
        banner.classList.add('is-visible');
    });

    setTimeout(() => {
        banner.classList.remove('is-visible');
        setTimeout(() => banner.remove(), 300);
    }, 2500);
}

function extractIssueIdFromUrl(url) {
    if (!url) return null;
    try {
        const parsed = new URL(url, window.location.origin);
        const match = parsed.pathname.match(/\/issues\/(\d+)/);
        return match ? match[1] : null;
    } catch (error) {
        return null;
    }
}

function clearHighlightedIssue() {
    if (drawerState.selectedElement) {
        drawerState.selectedElement.classList.remove(SELECTED_CLASS);
        drawerState.selectedElement = null;
    }
}

function highlightIssueContext(issueUrl, triggerElement = null) {
    const issueId = extractIssueIdFromUrl(issueUrl);
    const candidate = findIssueElement({ issueId, triggerElement });

    if (candidate) {
        if (drawerState.selectedElement && drawerState.selectedElement !== candidate) {
            drawerState.selectedElement.classList.remove(SELECTED_CLASS);
        }
        drawerState.selectedElement = candidate;
        candidate.classList.add(SELECTED_CLASS);
    } else {
        clearHighlightedIssue();
    }
}

function findIssueElement({ issueId, triggerElement }) {
    const fromTrigger = locateIssueElementFromAnchor(triggerElement);
    if (fromTrigger) {
        return fromTrigger;
    }

    if (!issueId) {
        return null;
    }

    const selectors = [
        `.issue-card[data-id="${issueId}"]`,
        `.issue-card[data-issue-id="${issueId}"]`,
        `.issue-card[data-card-id="${issueId}"]`,
        `tr.hascontextmenu[data-id="${issueId}"]`,
        `tr.hascontextmenu[data-issue-id="${issueId}"]`,
        `tr#issue-${issueId}`,
        `tr.issue[data-id="${issueId}"]`,
        `tr.issue-${issueId}`,
        `tr[data-id="${issueId}"]`
    ];

    for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element && !element.closest('.redmana-drawer')) {
            return element;
        }
    }

    return null;
}

function locateIssueElementFromAnchor(anchor) {
    if (!anchor) return null;
    if (anchor.closest('.redmana-drawer')) {
        return null;
    }
    const element = anchor.closest('.issue-card');
    if (element && !element.closest('.redmana-drawer')) {
        return element;
    }
    const row = anchor.closest('tr.hascontextmenu');
    if (row && !row.closest('.redmana-drawer')) {
        return row;
    }
    const fallbackRow = anchor.closest('tr.issue');
    if (fallbackRow && !fallbackRow.closest('.redmana-drawer')) {
        return fallbackRow;
    }
    return null;
}

function openIssueDrawer(issueUrl, options = {}) {
    const elements = ensureDrawerElements();

    const absoluteUrl = resolveIssueUrl(issueUrl);
    if (!drawerState.isOpen) {
        drawerState.baseUrl = window.location.href;
    }

    claimDrawerHistory('issue', absoluteUrl, () => {
        highlightIssueContext(absoluteUrl, options.triggerElement || null);

        drawerState.isOpen = true;
        drawerState.currentUrl = absoluteUrl;

        bringDrawerToFront(elements.container);
        elements.container.classList.add('is-open');
        elements.drawer.setAttribute('aria-hidden', 'false');
        if (document.body) {
            document.body.classList.add(BODY_DRAWER_CLASS);
        }

        loadIssueIntoDrawer(absoluteUrl, { triggerElement: options.triggerElement || null });
    });
}

function handleDocumentClick(event) {
    if (event.defaultPrevented || event.button !== 0) return;
    if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

    const anchor = event.target.closest('a[href]');
    if (!anchor) return;
    if (!shouldHandleIssueLink(anchor)) return;

    const issueUrl = resolveIssueUrl(anchor.getAttribute('href'));
    event.preventDefault();
    event.stopPropagation();

    openIssueDrawer(issueUrl, { triggerElement: anchor });
}

function handlePopState(event) {
    const currentUrl = window.location.href;
    drawerHistoryPending = false;


    const layer = drawerLayers.pop();
    if (layer) {
        drawerLayerClosers[layer]();
        lastKnownUrl = window.location.href;

        const claim = pendingDrawerClaim;
        pendingDrawerClaim = null;
        if (claim) claim();
        return;
    }
    pendingDrawerClaim = null;

    const state = event && event.state;
    const hasDrawerFlag = !!(state && state.redmanaDrawer === true);
    const urlChanged = currentUrl !== lastKnownUrl;

    if (!hasDrawerFlag && urlChanged) {
        window.location.assign(currentUrl);
        lastKnownUrl = currentUrl;
        return;
    }

    lastKnownUrl = currentUrl;
}

function handleKeyDown(event) {
    const top = topDrawerLayer();
    if (event.key === 'Escape' && top) {
        requestDrawerLayerClose(top);
    }
}

function initAssigneeEnhancement() {
    if (window[ASSIGNEE_INIT_FLAG]) return;
    window[ASSIGNEE_INIT_FLAG] = true;

    enhanceAllAssigneeSelects();
    observeAssigneeSelects();
}

function enhanceAllAssigneeSelects() {
    document.querySelectorAll(ASSIGNEE_SELECT_SELECTOR).forEach(enhanceAssigneeSelect);
}

function enhanceAssigneeSelect(select) {
    if (!(select instanceof HTMLSelectElement)) return;
    if (select.name !== 'issue[assigned_to_id]') return;

    rebuildLatestOptgroup(select);

    if (!select.dataset.redmanaAssigneeListener) {
        select.addEventListener('change', handleAssigneeChange);
        select.dataset.redmanaAssigneeListener = 'true';
    }
}

function handleAssigneeChange(event) {
    const select = event.currentTarget;
    if (!(select instanceof HTMLSelectElement)) return;

    const value = select.value;
    if (!value) return;

    const selectedOption = select.selectedOptions[0];
    const label = selectedOption ? selectedOption.textContent.trim() : '';
    if (!label) return;

    updateLatestAssignees({ id: value.toString(), name: label });
    document.querySelectorAll(ASSIGNEE_SELECT_SELECTOR).forEach(rebuildLatestOptgroup);
}

function rebuildLatestOptgroup(select) {
    if (!(select instanceof HTMLSelectElement)) return;
    if (select.dataset.redmanaRebuilding === 'true') {
        return;
    }
    select.dataset.redmanaRebuilding = 'true';

    try {
        const currentValue = select.value;
        const latestGroup = ensureLatestGroup(select);

        const stored = loadLatestAssignees();
        const optionMap = new Map();

        Array.from(select.options).forEach(option => {
            const parentGroup = option.parentElement;
            if (!option.value) return;
            if (parentGroup && parentGroup.getAttribute('data-redmana-latest-group') === 'true') return;
            optionMap.set(option.value, option.textContent.trim());
        });

        const filtered = stored.filter(item => optionMap.has(item.id));
        if (filtered.length !== stored.length) {
            saveLatestAssignees(filtered);
        }

        if (!filtered.length) {
            if (latestGroup) {
                latestGroup.remove();
            }
            return;
        }

        if (latestGroup) {
            latestGroup.innerHTML = '';
        }

        const fragment = document.createDocumentFragment();
        filtered.forEach(item => {
            const clone = document.createElement('option');
            clone.value = item.id;
            clone.textContent = optionMap.get(item.id) || item.name;
            clone.setAttribute('data-redmana-latest-option', 'true');
            fragment.appendChild(clone);
        });

        if (latestGroup) {
            latestGroup.appendChild(fragment);
        }

        if (currentValue && select.value !== currentValue) {
            select.value = currentValue;
        }
    } finally {
        setTimeout(() => {

            if (select.dataset.redmanaRebuilding === 'true') {
                delete select.dataset.redmanaRebuilding;
            }
        }, 0);
    }
}

function ensureLatestGroup(select) {
    let latestGroup = select.querySelector('optgroup[data-redmana-latest-group="true"]');
    if (!latestGroup) {
        latestGroup = document.createElement('optgroup');
        latestGroup.label = LATEST_OPTGROUP_LABEL;
        latestGroup.setAttribute('data-redmana-latest-group', 'true');
        const insertBefore = findLatestGroupInsertPosition(select);
        select.insertBefore(latestGroup, insertBefore);
    }
    return latestGroup;
}

function findLatestGroupInsertPosition(select) {
    const children = Array.from(select.childNodes);
    for (let i = 0; i < children.length; i += 1) {
        const node = children[i];
        if (node.nodeType === Node.TEXT_NODE && node.textContent.trim() === '') {
            return;
        }
        if (node.nodeType === Node.ELEMENT_NODE) {
            const element = node;
            if (element.tagName === 'OPTION' && element.value === '') {
                return element.nextSibling;
            }
            if (element.tagName === 'OPTGROUP' && element.getAttribute('data-redmana-latest-group') === 'true') {
                continue;
            }
            return element;
        }
        return node;
    }
    return null;
}

function loadLatestAssignees() {
    try {
        const raw = localStorage.getItem(LATEST_ASSIGNEES_KEY);
        if (!raw) return [];
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed)) return [];
        return parsed.filter(item => item && typeof item.id === 'string' && typeof item.name === 'string');
    } catch (error) {

        return [];
    }
}

function saveLatestAssignees(list) {
    try {
        localStorage.setItem(LATEST_ASSIGNEES_KEY, JSON.stringify(list.slice(0, MAX_LATEST_ASSIGNEES)));
    } catch (error) {

    }
}

function updateLatestAssignees(entry) {
    if (!entry || !entry.id) return;
    const cleanedName = (entry.name || '').trim();
    const normalizedEntry = {
        id: entry.id.toString(),
        name: cleanedName || entry.name || entry.id.toString()
    };

    const list = loadLatestAssignees().filter(item => item.id !== normalizedEntry.id);
    list.unshift(normalizedEntry);
    saveLatestAssignees(list);
}

function observeAssigneeSelects() {
    if (assigneeObserver) return;
    assigneeObserver = new MutationObserver(mutations => {
        mutations.forEach(mutation => {
            if (mutation.type !== 'childList') return;

            const target = mutation.target;
            if (target instanceof HTMLSelectElement && target.matches(ASSIGNEE_SELECT_SELECTOR)) {
                enhanceAssigneeSelect(target);
            }

            mutation.addedNodes.forEach(node => {
                if (!(node instanceof Element)) return;
                if (node.matches && node.matches(ASSIGNEE_SELECT_SELECTOR)) {
                    enhanceAssigneeSelect(node);
                } else if (node.querySelectorAll) {
                    node.querySelectorAll(ASSIGNEE_SELECT_SELECTOR).forEach(enhanceAssigneeSelect);
                }
            });
        });
    });

    assigneeObserver.observe(document.body, { childList: true, subtree: true });
}

function initIssueDrawer() {
    if (window[DRAWER_INIT_FLAG]) return;
    window[DRAWER_INIT_FLAG] = true;

    drawerLayerClosers.issue = closeDrawerInternal;
    document.addEventListener('click', handleDocumentClick, true);
    document.addEventListener('mouseover', handleIssuePrefetchHover, true);
    document.addEventListener('mouseout', cancelPrefetchHover, true);
    document.addEventListener('mousedown', handleIssuePrefetchIntent, true);
    window.addEventListener('popstate', handlePopState);
    document.addEventListener('keydown', handleKeyDown);
}

if (isRedmine) {
    initIssueDrawer();
    initAssigneeEnhancement();
}
