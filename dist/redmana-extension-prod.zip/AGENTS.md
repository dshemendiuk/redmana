
# Project: Chrome Extension "Redmana" for Redmine

## 1. Project Goal

The primary goal is to develop a Google Chrome extension named "Redmana" that enhances the user experience of a Redmine instance, making it behave more like modern project management tools such as Asana. The extension will modify the frontend behavior of Redmine pages through content scripts, focusing on the Agile Board and issue tracking workflows.

## 2. Core Features

### 2.1. Agile Board Enhancements
- **Draggable Columns:** On the Agile Board page (e.g., `*/agile/board`), users should be able to drag and drop columns to reorder them. The new column order must be persisted in the browser's `localStorage`.
- **Drag-and-Scroll for Cards:** When dragging a task card to the top or bottom edge of the viewport, the page should automatically scroll up or down, respectively. This should use the native Redmine Agile plugin's mechanism for saving the card order.

### 2.2. Issue Page Enhancements
- **Task Drawer:**
    - Intercept clicks on all links pointing to a Redmine issue (e.g., `*/issues/12345`).
    - Instead of navigating to a new page, open a side drawer on the right side of the screen.
    - Use `fetch` to get the issue page's HTML, extract only the main content area (task details, history, comments), and render it inside the drawer. The Redmine header and sidebar should be excluded.
    - Update the browser's address bar with the URL of the opened issue using the History API (`pushState`).
    - If a link to another issue is clicked *within* the drawer, the drawer's content should be replaced with the new issue's content.
- **Image Lightbox:**
    - Find all thumbnail images within the issue description or comments.
    - When a user clicks on a thumbnail, display the full-size image in a modal lightbox overlay instead of opening it on a new page.
- **Assignee Dropdown:**
    - In the issue edit form, locate the "Assignee" dropdown (`name="issue[assigned_to_id]"`).
    - Dynamically add an `<optgroup>` labeled "Latest" at the top of the list.
    - This group should contain the last 10 users to whom the current user has assigned issues. This list should be filtered to only include users who are already present in the original dropdown for the current project. The history of assigned users should be stored in `localStorage`.

## 3. Technical Requirements

- The solution must be a Chrome extension using Manifest V3.
- All modifications must be done via content scripts (JavaScript and CSS) injected into the Redmine pages.
- Settings and user data (like column order and latest assignees) should be stored in `localStorage`.
- The code should be clean, well-commented, and robust enough to handle potential changes in Redmine's HTML structure gracefully.
- No external libraries should be used unless absolutely necessary. Prioritize vanilla JavaScript solutions.

## 4. Deliverables

- A complete, functional Chrome extension.
- A `PLAN.md` file outlining the development steps.
- All necessary assets for publishing to the Chrome Web Store (icons, manifest, etc.).
